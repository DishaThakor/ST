package WEbelementexamples;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
public class TakeScreenshot1 {

	public static void main(String[] args) {
		String baseUrl = "http://demo.guru99.com/test/newtours/";
		System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\thirt\\Downloads\\chromedriver-win64 (2)\\chromedriver-win64\\chromedriver.exe"); 
		WebDriver driver = new ChromeDriver(); 
		driver.manage().deleteAllCookies(); 
		driver.manage().window().maximize(); 
		driver.get(baseUrl); 
		 
		//Use TakesScreenshot method to capture screenshot
		TakesScreenshot screenshot = (TakesScreenshot)driver;
		
		try {
			File source = screenshot.getScreenshotAs(OutputType.FILE);
			FileHandler.copy(source, new File("C:\\Users\\thirt\\OneDrive\\Documents\\Testing\\screenCaptureScreenshot.png"));
		} catch (WebDriverException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		/*
		 * //Saving the screenshot in desired location
		 
		File source = screenshot.getScreenshotAs(OutputType.FILE);
		//Path to the location to save screenshot
		FileUtils.copyFile(source, new File("./SeleniumScreenshots/Screen.png"));
		*/
		
		System.out.println("Screenshot is captured");
		
		
		driver.quit();
	}

}
