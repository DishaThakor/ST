package WEbelementexamples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class accessingimagelink {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\thirt\\Downloads\\chromedriver-win64 (2)\\chromedriver-win64\\chromedriver.exe"); 
		WebDriver driver = new ChromeDriver(); 
		driver.manage().deleteAllCookies(); 
		driver.manage().window().maximize(); 
		 String baseUrl = "https://www.facebook.com/login/identify?ctx=recover";	
		 driver.get(baseUrl);	
		//click on the "Facebook" logo on the upper left portion		
		 driver.findElement(By.cssSelector("a[title=\"Go to Facebook home\"]")).click();

		//verify that we are back on Facebook's homepage

		if (driver.getTitle().equals("Facebook - log in or sign up")) 

		{

		            System.out.println("We are back to Facebook's homepage");

		        } else {

		            System.out.println("We are NOT at Facebook's homepage");

		        }

		driver.close();


}
}