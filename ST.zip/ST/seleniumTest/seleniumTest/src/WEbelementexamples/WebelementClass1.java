package WEbelementexamples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebelementClass1 {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\thirt\\Downloads\\chromedriver-win64 (2)\\chromedriver-win64\\chromedriver.exe"); 
		WebDriver driver = new ChromeDriver(); 
		driver.manage().deleteAllCookies(); 
		driver.manage().window().maximize(); 
		driver.get("https://www.naukri.com/registration/createAccount");
		
		
		WebElement obj =     driver.findElement(By.id("name"));
	    WebElement obj1 =  driver.findElement(By.id("email"));
		
		obj.sendKeys("java");
        obj1.sendKeys("test@aa.ocm");		
		
		//Thread.sleep(1000);
		
		  //x2.click();		
			
}
}
