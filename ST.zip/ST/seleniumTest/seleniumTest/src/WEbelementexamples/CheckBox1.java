package WEbelementexamples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckBox1 {

	public static void main(String[] args) {
		// Selecting CheckBox		
       
		System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\thirt\\Downloads\\chromedriver-win64 (2)\\chromedriver-win64\\chromedriver.exe"); 
		WebDriver driver = new ChromeDriver(); 
		driver.manage().deleteAllCookies(); 
		driver.manage().window().maximize(); 
		driver.get("https://demo.guru99.com/test/radio.html");
		WebElement option1 = driver.findElement(By.id("vfb-6-0"));							
         // This will Toggle the Check box 		
        option1.click();			
         
        // Check whether the Check box is toggled on 		
        if (option1.isSelected()) {					
            System.out.println("Checkbox is Toggled On");					

        } else {			
            System.out.println("Checkbox is Toggled Off");					
        }		
         
	}

}
