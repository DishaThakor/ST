package seleniumTest;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class OpenChrome {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated mev5gthod stub
				System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\thirt\\Downloads\\chromedriver-win64 (2)\\chromedriver-win64\\chromedriver.exe"); 
				WebDriver driver = new ChromeDriver(); 
				
				//driver.manage().deleteAllCookies(); 
				Dimension d = new Dimension(500, 500); 
				  driver.manage().window().setSize(d); 
				driver.get("https://www.gmail.com/"); 
				//driver.manage().window().maximize(); 
		   
				
				  Thread.sleep(2000); 
				
				  driver.quit(); 
				
				  //To set the size of the window 
				  /*Dimension d = new Dimension(500, 500); 
				  driver.manage().window().setSize(d); 
				  Thread.sleep(2000); 
				   */
				  //To set the position of the window 
				 /* Point p = new Point(250, 250); 
				  driver.manage().window().setPosition(p); 
				  Thread.sleep(2000); 
				*/
				  //driver.manage().window().maximize(); 
		
				 
		
	}

}
