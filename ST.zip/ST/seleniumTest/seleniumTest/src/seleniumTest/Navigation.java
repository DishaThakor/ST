package seleniumTest;

import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;

public class Navigation {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.ie.driver", 
				"C:\\Users\\thirt\\Downloads\\IEDriverServer_x64_4.14.0\\IEDriverServer.exe"); 
			 
		
		InternetExplorerOptions options = new InternetExplorerOptions();
		options.introduceFlakinessByIgnoringSecurityDomains();
		
		
		
		InternetExplorerDriver driver = new InternetExplorerDriver(options); 
			
		driver.manage().window().maximize(); 
		driver.manage().deleteAllCookies();
		
		driver.get("https://www.gmail.com/");
			 
		driver.navigate().to("https://www.facebook.com/"); 
	   // Thread.sleep(1000); 
	    driver.quit(); 

	}

}
