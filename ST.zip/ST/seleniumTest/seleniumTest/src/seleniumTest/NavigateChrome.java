package seleniumTest;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class NavigateChrome {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\thirt\\Downloads\\chromedriver-win64 (2)\\chromedriver-win64\\chromedriver.exe"); 
				WebDriver driver = new ChromeDriver(); 
				
				driver.manage().deleteAllCookies(); 
				   
				  //To set the size of the window 
				  //To maximize the window 
				  driver.manage().window().maximize(); 
				
				
				driver.get("https://www.gmail.com/"); 
				
				driver.navigate().to("https://www.facebook.com/"); 
				  Thread.sleep(1000); 
				   
				   
				  //To navigate to previous page 
				  driver.navigate().back(); 
				  Thread.sleep(1000); 
				//To navigate to next page 
				  driver.navigate().forward(); 
				  Thread.sleep(1000); 
				   
				  //Refresh current web page 
				  driver.navigate().refresh(); 
	}

}
