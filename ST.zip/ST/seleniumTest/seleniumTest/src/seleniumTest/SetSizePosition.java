package seleniumTest;

import java.awt.Dimension;

import org.openqa.selenium.Point;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;

public class SetSizePosition {

	public static void main(String[] args) {
		 
		
		System.setProperty("webdriver.ie.driver", 
				"C:\\Users\\thirt\\Downloads\\IEDriverServer_x64_4.14.0\\IEDriverServer.exe"); 
			 
		
		InternetExplorerOptions options = new InternetExplorerOptions();
		options.introduceFlakinessByIgnoringSecurityDomains();
		
		
		
		InternetExplorerDriver driver = new InternetExplorerDriver(options); 
			
			 driver.get("https://www.gmail.com/");
		
		driver.manage().deleteAllCookies(); 
		   
		  //To set the size of the window 
		  org.openqa.selenium.Dimension d =  new org.openqa.selenium.Dimension(100, 100); 
		  driver.manage().window().setSize(d); 
		  try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		   
		  //To set the position of the window 
		 Point p = new Point(250, 250); 
		  driver.manage().window().setPosition(p); 
		  try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		   
		  //To maximize the window 
		  driver.manage().window().maximize();
	}

}
