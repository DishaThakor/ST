package seleniumTest;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CloseChrome {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\thirt\\Downloads\\chromedriver-win64 (2)\\chromedriver-win64\\chromedriver.exe"); 
				WebDriver driver = new ChromeDriver(); 
				
				driver.manage().deleteAllCookies(); 
				   
				 
				  //To maximize the window 
				  driver.manage().window().maximize(); 
				
				
				driver.get("https://www.gmail.com/"); 

				Thread.sleep(2000); 
				   
				  //To close all the browsers 
				  driver.quit(); 
	}

}
