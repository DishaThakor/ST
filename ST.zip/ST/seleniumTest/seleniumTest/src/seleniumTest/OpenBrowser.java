package seleniumTest;

import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;

public class OpenBrowser {

	public static void main(String[] args) {

		System.setProperty("webdriver.ie.driver", 
				"C:\\Users\\thirt\\Downloads\\IEDriverServer_x64_4.14.0\\IEDriverServer.exe"); 
			 
		
		InternetExplorerOptions options = new InternetExplorerOptions();
		options.introduceFlakinessByIgnoringSecurityDomains();
		
		
		
		InternetExplorerDriver driver = new InternetExplorerDriver(options); 
			
			 driver.get("https://www.facebook.com/"); 
				driver.manage().window().maximize(); 
	}

}
