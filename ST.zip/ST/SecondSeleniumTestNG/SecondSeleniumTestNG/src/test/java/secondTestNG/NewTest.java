package secondTestNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class NewTest {
	WebDriver driver;
  @Test
  public void f() {
	  
	  WebElement obj =     driver.findElement(By.id("name"));
	   WebElement obj1 =  driver.findElement(By.id("email"));
		
		obj.sendKeys("java");
      obj1.sendKeys("test@aa.ocm");	
	  //driver.findElement(By.id("user_full_name")).sendKeys("user_name");
	  //driver.findElement(By.id("user_email_login")).sendKeys("email_id");
	//  driver.findElement(By.id("user_password")).sendKeys("password");
	  //driver.findElement(By.xpath("//input[@name='terms_and_conditions']")).click();
	  //driver.findElement(By.id("user_submit")).click();
	  
  }
  @BeforeMethod
  public void beforeMethod() {
	  driver.get("https://www.naukri.com/");
	  driver.findElement(By.id("register_Layer")).click();
	  System.out.println("We are currently on the following URL" +driver.getCurrentUrl());
  }

  @AfterMethod
  public void afterMethod() {
	  System.out.println(driver.getCurrentUrl());
  }

  @BeforeClass
  public void beforeClass() {
	  
	  
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\thirt\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  driver.manage().window().maximize();
  }

  @AfterClass
  public void afterClass() {
	  
	  driver.quit();
  }

}
